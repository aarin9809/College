from django.http import HttpResponse, HttpResponseRedirect, JsonResponse, FileResponse
from django.shortcuts import render, redirect
from django.contrib import auth
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib import messages
from .models import User, Animal
from django.db import connection
from django.db import models

def main(request):
    with connection.cursor() as cursor:
        cursor.execute("SELECT COUNT(*) FROM Animal WHERE organ_species IS NOT NULL and take_purpose IS NULL")
        organ_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM Animal WHERE blood_cc IS NOT NULL and take_purpose IS NULL")
        blood_count = cursor.fetchone()[0]

    context = {
        'organ_count': organ_count,
        'blood_count': blood_count
    }

    return render(request, 'main.html', context)

def confirm(request):
    return render(request, 'confirm.html')

def about(request):
    return render(request, 'about.html')

def kakaomap(request):
    return render(request, 'kakaomap.html')


def signup(request):
    if request.method == "POST":
        personal_id = request.POST.get('personal_id')
        id = request.POST.get('id')
        passwd = request.POST.get('passwd')
        username = request.POST.get('username')

        # 유효성 검사
        if not personal_id or not id or not passwd or not username:
            messages.error(request, '모든 필수 입력란을 작성해주세요.')
            return render(request, 'signup.html')

        # 사용자 생성
        user = User(
            personal_id=personal_id,
            id=id,
            passwd=passwd,
            username=username,
        )
        user.save()
        return redirect('/')  # 메인 페이지로 리다이렉트

    return render(request, 'signup.html')


def login(request):
    if request.method == 'POST':
        id = request.POST['id']
        passwd = request.POST['passwd']

        try:
            user = User.objects.get(id=id)
        except User.DoesNotExist:
            messages.error(request, 'ID가 존재하지 않습니다.')
            return render(request, 'login.html')

        if user.passwd == passwd:
            request.session['user_id'] = user.id
            request.session['username'] = user.username
            return redirect('/')  # 'home'은 홈페이지로 이동하는 라우트를 의미합니다.
        else:
            messages.error(request, '비밀번호가 틀렸습니다.')
            return render(request, 'login.html')

    return render(request, 'login.html')


def logout(request):
    try:
        del request.session['user_id']
        del request.session['username']
    except KeyError:
        messages.error(request, '로그아웃 중 문제가 발생했습니다.')
        return redirect('/')  # 문제 발생 시 홈페이지로 리다이렉트
    return redirect('/')  # 로그아웃 후 홈페이지로 리다이렉트


def bloodDonation(request):
    if request.method == 'POST':
        ani_code = request.POST.get('ani_code')
        past_disease = request.POST.get('past_disease')
        blood_species = request.POST.get('blood_species')
        blood_type = request.POST.get('blood_type')
        blood_cc = request.POST.get('blood_cc')
        age = request.POST.get('age')
        species = request.POST.get('species')

        animal = Animal(
            ani_code=ani_code,
            past_disease=past_disease,
            blood_species=blood_species,
            blood_type=blood_type,
            blood_cc=blood_cc,
            age=age,
            species=species
        )
        animal.save()
        return redirect('/confirm/')  # 확인 페이지로 이동
    return render(request, 'bloodDonation.html')

def bloodTake(request):
    if request.method == 'POST':
        ani_code = request.POST.get('ani_code')
        take_purpose = request.POST.get('take_purpose')
        blood_cc = request.POST.get('blood_cc')
        species = request.POST.get('species')
        blood_type = request.POST.get('blood_type')

        animal = Animal(
            ani_code=ani_code,
            take_purpose=take_purpose,
            blood_cc=blood_cc,
            species=species,
            blood_type=blood_type
        )
        animal.save()
        return redirect('/confirm/')  # 확인 페이지로 이동
    return render(request, 'bloodTake.html')


def organDonation(request):
    if request.method == 'POST':
        ani_code = request.POST.get('ani_code')
        past_disease = request.POST.get('past_disease')
        organ_species = request.POST.get('organ_species')
        blood_type = request.POST.get('blood_type')
        age = request.POST.get('age')
        species = request.POST.get('species')

        animal = Animal(
            ani_code=ani_code,
            past_disease=past_disease,
            organ_species=organ_species,
            blood_type=blood_type,
            age=age,
            species=species
        )
        animal.save()
        return redirect('/confirm/')    # 확인 홈페이지로 이동
    return render(request, 'organDonation.html')

def organTake(request):
    if request.method == 'POST':
        ani_code = request.POST.get('ani_code')
        take_purpose = request.POST.get('take_purpose')
        organ_species = request.POST.get('organ_species')
        species = request.POST.get('species')
        blood_type = request.POST.get('blood_type')

        animal = Animal(
            ani_code=ani_code,
            take_purpose=take_purpose,
            organ_species=organ_species,
            species=species,
            blood_type=blood_type
        )
        animal.save()
        return redirect('/confirm/')  # 확인 페이지로 이동
    return render(request, 'organTake.html')

