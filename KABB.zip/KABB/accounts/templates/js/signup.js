document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();

    var personal_no = document.querySelector('input[name="personal_no"]').value;
    var id = document.querySelector('input[name="id"]').value;
    var password1 = document.querySelector('input[name="password1"]').value;
    var email = document.querySelector('input[name="email"]').value;
    var animal_code = document.querySelector('input[name="animal_code"]').value;
    var animal_species = document.querySelector('input[name="animal_species"]').value;

    if (!personal_no || !id || !password1 || !email) {
        alert('필수 항목을 모두 입력해주세요.');
        return;
    }

    // 나머지 입력 검증 및 회원가입 처리 로직을 여기에 작성합니다.
});