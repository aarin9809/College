# accounts/urls.py
from django.urls import path, include
from .views import *
from django.contrib import admin

app_name = 'accounts'
urlpatterns = [
    path('', main, name='main'),
    path('signup/', signup, name='signup'),
    path('login/', login, name='login'),
    path('logout/', logout, name='login'),
    path('confirm/', confirm, name='confirm'),
    path('bloodDonation/', bloodDonation, name='bloodDonation'),
    path('bloodTake/', bloodTake, name='bloodTake'),
    path('organDonation/', organDonation, name='organDonation'),
    path('organTake/', organTake, name='organTake'),
    path('about/', about, name='about'),
    path('kakaomap/', kakaomap, name='kakaomap'),
]