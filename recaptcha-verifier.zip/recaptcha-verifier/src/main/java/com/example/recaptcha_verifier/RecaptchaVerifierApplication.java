package com.example.recaptcha_verifier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecaptchaVerifierApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecaptchaVerifierApplication.class, args);
	}

}
