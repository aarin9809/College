package com.example.recaptcha_verifier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecaptchaVerifierApplicationTests {

	@Test
	void contextLoads() {
	}

}
