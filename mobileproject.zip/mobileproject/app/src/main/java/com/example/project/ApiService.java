package com.example.project;

import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiService {
    @POST("/api/recaptcha/verify")
    Call<Boolean> verifyRecaptcha(@Query("token") String token);
}
