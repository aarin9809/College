package com.example.project;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.project.databinding.ActivityLoginBinding;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private ActivityLoginBinding binding;
    private FirebaseFirestore db;
    private static final String SITE_KEY = "YOUR_SITE_KEY_HERE"; // 여기에 사이트 키를 입력하세요
    private boolean recaptchaVerified = false;
    private ApiService apiService;

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            currentUser.reload();
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);

        binding.recaptchaButton.setOnClickListener(v -> SafetyNet.getClient(this).verifyWithRecaptcha(SITE_KEY)
                .addOnSuccessListener(this, response -> {
                    String userResponseToken = response.getTokenResult();
                    if (!userResponseToken.isEmpty()) {
                        // 서버로 토큰을 보내어 검증합니다.
                        verifyTokenOnServer(userResponseToken);
                    }
                })
                .addOnFailureListener(this, e -> {
                    Log.e("reCAPTCHA", "Error: " + e.toString());
                    Toast.makeText(LoginActivity.this, "reCAPTCHA failed. Try again.", Toast.LENGTH_SHORT).show();
                })
        );

        binding.loginButton.setOnClickListener(v -> {
            String studentId = binding.studentIdEditText.getText().toString().trim();
            String password = binding.passwordEditText.getText().toString().trim();

            if (validateInputs(studentId, password)) {
                // reCAPTCHA를 통과한 경우에만 로그인 수행
                if (recaptchaVerified) {
                    performLogin(studentId, password);
                } else {
                    Toast.makeText(LoginActivity.this, "Please complete the reCAPTCHA.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean validateInputs(String stu_id, String password) {
        if (stu_id.isEmpty()) {
            binding.studentIdEditText.setError("학번을 입력하세요");
            return false;
        }

        if (password.isEmpty()) {
            binding.passwordEditText.setError("비밀번호를 입력하세요");
            return false;
        }

        return true;
    }

    private void performLogin(String studentId, String password) {
        db.collection("Students")
                .whereEqualTo("stu_id", studentId)
                .whereEqualTo("password", password)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && !task.getResult().isEmpty()) {
                        // 로그인 성공, 사용자 정보 업데이트
                        Toast.makeText(LoginActivity.this, "로그인 성공", Toast.LENGTH_SHORT).show();
                        // 다음 화면으로 이동
                    } else {
                        // 로그인 실패
                        Toast.makeText(LoginActivity.this, "로그인 실패: 유효하지 않은 학번 또는 비밀번호", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void verifyTokenOnServer(String token) {
        Call<Boolean> call = apiService.verifyRecaptcha(token);
        call.enqueue(new Callback<Boolean>() {
            @Override
            public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                if (response.isSuccessful() && response.body() != null) {
                    recaptchaVerified = response.body();
                    if (recaptchaVerified) {
                        Toast.makeText(LoginActivity.this, "reCAPTCHA verified successfully.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginActivity.this, "Failed to verify reCAPTCHA.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Failed to verify reCAPTCHA.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Boolean> call, Throwable t) {
                recaptchaVerified = false;
                Toast.makeText(LoginActivity.this, "Failed to verify reCAPTCHA.", Toast.LENGTH_SHORT).show();
                Log.e("reCAPTCHA", "Error: " + t.getMessage());
            }
        });
    }
}
